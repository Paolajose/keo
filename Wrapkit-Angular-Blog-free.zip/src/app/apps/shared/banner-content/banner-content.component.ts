import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-banner-content',
  templateUrl: './banner-content.component.html',
  styleUrls: ['./banner-content.component.css']
})
export class BannerContentComponent implements OnInit {

  constructor() {
  }

  ngOnInit(): void {
  }

}


